//
//  main.m
//  AudioStreamServer
//
//  Created by 林伟池 on 2017/4/1.
//  Copyright © 2017年 loying. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
